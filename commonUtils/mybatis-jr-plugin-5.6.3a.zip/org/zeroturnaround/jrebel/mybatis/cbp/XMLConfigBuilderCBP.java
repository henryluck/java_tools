/*    */ package org.zeroturnaround.jrebel.mybatis.cbp;
/*    */ 
/*    */ import org.zeroturnaround.bundled.javassist.ClassPool;
/*    */ import org.zeroturnaround.bundled.javassist.CtClass;
/*    */ import org.zeroturnaround.bundled.javassist.CtConstructor;
/*    */ import org.zeroturnaround.bundled.javassist.CtField;
/*    */ import org.zeroturnaround.bundled.javassist.CtMethod;
/*    */ import org.zeroturnaround.bundled.javassist.CtNewMethod;
/*    */ import org.zeroturnaround.javarebel.integration.support.JavassistClassBytecodeProcessor;
/*    */ import org.zeroturnaround.jrebel.mybatis.JrConfiguration;
/*    */ import org.zeroturnaround.jrebel.mybatis.JrXMLConfigBuilder;
/*    */ import org.zeroturnaround.jrebel.mybatis.SqlMapReloader;
/*    */ 
/*    */ public class XMLConfigBuilderCBP extends JavassistClassBytecodeProcessor
/*    */ {
/*    */   public void process(ClassPool cp, ClassLoader cl, CtClass ctClass)
/*    */     throws Exception
/*    */   {
/* 23 */     ctClass.addInterface(cp.get(JrXMLConfigBuilder.class.getName()));
/*    */ 
/* 25 */     ctClass.addField(new CtField(cp.get(SqlMapReloader.class.getName()), "reloader", ctClass));
/*    */ 
/* 27 */     CtConstructor[] constructors = ctClass.getDeclaredConstructors();
/* 28 */     for (int i = 0; i < constructors.length; i++) {
/* 29 */       CtConstructor constructor = constructors[i];
/* 30 */       if (constructor.callsSuper()) {
/* 31 */         constructor.insertAfter("if (configuration instanceof " + JrConfiguration.class
/* 32 */           .getName() + ") {" + "  $0.reloader = ((" + JrConfiguration.class
/* 33 */           .getName() + ")configuration).getReloader();" + "  $0.reloader.setConfigBuilder($0);" + "}");
/*    */       }
/*    */ 
/*    */     }
/*    */ 
/* 40 */     CtMethod origMethod = ctClass.getDeclaredMethod("parse");
/* 41 */     CtMethod copyMethod = CtNewMethod.copy(origMethod, "__parse", ctClass, null);
/* 42 */     ctClass.addMethod(copyMethod);
/* 43 */     origMethod.setBody("{  if ($0.reloader == null) {    return __parse();  }  $0.reloader.enterConf();  try {    return __parse();  } finally {    $0.reloader.exitConf();  }}");
/*    */ 
/* 57 */     ctClass.addMethod(CtNewMethod.make("public void reinit() {  parsed = false;  __parse();}", ctClass));
/*    */   }
/*    */ }

/* Location:           F:\eclipse-jee-juno-SR2-win32\plugins\org.zeroturnaround.eclipse.embedder_5.3.1.RELEASE-201307081557\jrebel\mybatis-jr-plugin-5.6.3a.jar
 * Qualified Name:     org.zeroturnaround.jrebel.mybatis.cbp.XMLConfigBuilderCBP
 * JD-Core Version:    0.6.0
 */