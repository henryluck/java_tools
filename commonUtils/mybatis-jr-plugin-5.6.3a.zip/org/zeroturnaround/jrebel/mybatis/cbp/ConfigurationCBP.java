/*    */ package org.zeroturnaround.jrebel.mybatis.cbp;
/*    */ 
/*    */ import org.zeroturnaround.bundled.javassist.ClassPool;
/*    */ import org.zeroturnaround.bundled.javassist.CtClass;
/*    */ import org.zeroturnaround.bundled.javassist.CtConstructor;
/*    */ import org.zeroturnaround.bundled.javassist.CtField;
/*    */ import org.zeroturnaround.bundled.javassist.CtMethod;
/*    */ import org.zeroturnaround.bundled.javassist.CtNewMethod;
/*    */ import org.zeroturnaround.javarebel.integration.support.JavassistClassBytecodeProcessor;
/*    */ import org.zeroturnaround.jrebel.mybatis.JrConfiguration;
/*    */ import org.zeroturnaround.jrebel.mybatis.JrInterceptorChain;
/*    */ import org.zeroturnaround.jrebel.mybatis.SqlMapReloader;
/*    */ 
/*    */ public class ConfigurationCBP extends JavassistClassBytecodeProcessor
/*    */ {
/*    */   public void process(ClassPool cp, ClassLoader cl, CtClass ctClass)
/*    */     throws Exception
/*    */   {
/* 21 */     ctClass.addInterface(cp.get(JrConfiguration.class.getName()));
/*    */ 
/* 23 */     ctClass.addField(new CtField(cp.get(SqlMapReloader.class.getName()), "reloader", ctClass));
/*    */ 
/* 25 */     CtConstructor[] constructors = ctClass.getConstructors();
/* 26 */     for (int i = 0; i < constructors.length; i++) {
/* 27 */       CtConstructor constructor = constructors[i];
/* 28 */       if (constructor.callsSuper()) {
/* 29 */         constructor.insertAfter("reloader = new " + SqlMapReloader.class.getName() + "($0);");
/*    */       }
/*    */     }
/*    */ 
/* 33 */     ctClass.addMethod(CtNewMethod.make("public " + SqlMapReloader.class
/* 34 */       .getName() + " getReloader() {" + "  return reloader;" + "}", ctClass));
/*    */ 
/* 39 */     ctClass.addMethod(CtNewMethod.make("public void reinit() {  loadedResources.clear();  ((" + JrInterceptorChain.class
/* 42 */       .getName() + ") interceptorChain).jrClear();" + "}", ctClass));
/*    */ 
/* 46 */     ctClass.getDeclaredMethod("isResourceLoaded").insertAfter("if (reloader.doReload($1)) {  loadedResources.remove($1);  $_ = false;}");
/*    */   }
/*    */ }

/* Location:           F:\eclipse-jee-juno-SR2-win32\plugins\org.zeroturnaround.eclipse.embedder_5.3.1.RELEASE-201307081557\jrebel\mybatis-jr-plugin-5.6.3a.jar
 * Qualified Name:     org.zeroturnaround.jrebel.mybatis.cbp.ConfigurationCBP
 * JD-Core Version:    0.6.0
 */