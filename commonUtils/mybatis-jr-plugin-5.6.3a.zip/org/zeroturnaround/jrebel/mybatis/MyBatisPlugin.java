/*     */ package org.zeroturnaround.jrebel.mybatis;
/*     */ 
/*     */ import org.zeroturnaround.javarebel.ClassResourceSource;
/*     */ import org.zeroturnaround.javarebel.Integration;
/*     */ import org.zeroturnaround.javarebel.IntegrationFactory;
/*     */ import org.zeroturnaround.javarebel.Plugin;
/*     */ import org.zeroturnaround.jrebel.mybatis.cbp.ConfigurationCBP;
/*     */ import org.zeroturnaround.jrebel.mybatis.cbp.DefaultSqlSessionFactoryCBP;
/*     */ import org.zeroturnaround.jrebel.mybatis.cbp.InterceptorChainCBP;
/*     */ import org.zeroturnaround.jrebel.mybatis.cbp.MapperAnnotationBuilderCBP;
/*     */ import org.zeroturnaround.jrebel.mybatis.cbp.MapperFactoryBeanCBP;
/*     */ import org.zeroturnaround.jrebel.mybatis.cbp.MapperRegistryCBP;
/*     */ import org.zeroturnaround.jrebel.mybatis.cbp.ReflectorCBP;
/*     */ import org.zeroturnaround.jrebel.mybatis.cbp.ResourcesCBP;
/*     */ import org.zeroturnaround.jrebel.mybatis.cbp.SqlSessionFactoryBeanCBP;
/*     */ import org.zeroturnaround.jrebel.mybatis.cbp.StrictMapCBP;
/*     */ import org.zeroturnaround.jrebel.mybatis.cbp.TypeAliasRegistryCBP;
/*     */ import org.zeroturnaround.jrebel.mybatis.cbp.XMLConfigBuilderCBP;
/*     */ 
/*     */ public class MyBatisPlugin
/*     */   implements Plugin
/*     */ {
/*     */   public void preinit()
/*     */   {
/*  15 */     ClassLoader cl = MyBatisPlugin.class.getClassLoader();
/*     */ 
/*  17 */     Integration integration = IntegrationFactory.getInstance();
/*     */ 
/*  19 */     integration.addIntegrationProcessor(cl, "org.apache.ibatis.io.Resources", new ResourcesCBP());
/*     */ 
/*  24 */     integration.addIntegrationProcessor(cl, new String[] { "org.apache.ibatis.builder.xml.XMLConfigBuilder", "pl.atena.ibatisbaf.core.config.ConfigBuilder" }, new XMLConfigBuilderCBP());
/*     */ 
/*  32 */     integration.addIntegrationProcessor(cl, "org.apache.ibatis.session.defaults.DefaultSqlSessionFactory", new DefaultSqlSessionFactoryCBP());
/*     */ 
/*  38 */     integration.addIntegrationProcessor(cl, "org.apache.ibatis.session.Configuration", new ConfigurationCBP());
/*     */ 
/*  44 */     integration.addIntegrationProcessor(cl, "org.apache.ibatis.session.Configuration$StrictMap", new StrictMapCBP());
/*     */ 
/*  50 */     integration.addIntegrationProcessor(cl, "org.apache.ibatis.binding.MapperRegistry", new MapperRegistryCBP());
/*     */ 
/*  56 */     integration.addIntegrationProcessor(cl, "org.apache.ibatis.reflection.Reflector", new ReflectorCBP());
/*     */ 
/*  62 */     integration.addIntegrationProcessor(cl, "org.mybatis.spring.SqlSessionFactoryBean", new SqlSessionFactoryBeanCBP());
/*     */ 
/*  68 */     integration.addIntegrationProcessor(cl, "org.apache.ibatis.builder.annotation.MapperAnnotationBuilder", new MapperAnnotationBuilderCBP());
/*     */ 
/*  74 */     integration.addIntegrationProcessor(cl, "org.apache.ibatis.type.TypeAliasRegistry", new TypeAliasRegistryCBP());
/*     */ 
/*  80 */     integration.addIntegrationProcessor(cl, "org.apache.ibatis.plugin.InterceptorChain", new InterceptorChainCBP());
/*     */ 
/*  86 */     integration.addIntegrationProcessor(cl, "org.mybatis.spring.mapper.MapperFactoryBean", new MapperFactoryBeanCBP());
/*     */   }
/*     */ 
/*     */   public boolean checkDependencies(ClassLoader cl, ClassResourceSource crs)
/*     */   {
/*  94 */     return crs.getClassResource("org.apache.ibatis.session.SqlSessionFactoryBuilder") != null;
/*     */   }
/*     */ 
/*     */   public String getAuthor() {
/*  98 */     return null;
/*     */   }
/*     */ 
/*     */   public String getDescription() {
/* 102 */     return "<li>Reloads modified SQL maps.</li>";
/*     */   }
/*     */ 
/*     */   public String getId() {
/* 106 */     return "mybatis_plugin";
/*     */   }
/*     */ 
/*     */   public String getName() {
/* 110 */     return "MyBatis plugin";
/*     */   }
/*     */ 
/*     */   public String getWebsite() {
/* 114 */     return null;
/*     */   }
/*     */ 
/*     */   public String getSupportedVersions() {
/* 118 */     return null;
/*     */   }
/*     */ 
/*     */   public String getTestedVersions() {
/* 122 */     return null;
/*     */   }
/*     */ }

/* Location:           F:\eclipse-jee-juno-SR2-win32\plugins\org.zeroturnaround.eclipse.embedder_5.3.1.RELEASE-201307081557\jrebel\mybatis-jr-plugin-5.6.3a.jar
 * Qualified Name:     org.zeroturnaround.jrebel.mybatis.MyBatisPlugin
 * JD-Core Version:    0.6.0
 */