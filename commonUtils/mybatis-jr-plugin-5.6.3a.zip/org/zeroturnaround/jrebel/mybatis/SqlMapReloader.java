/*     */ package org.zeroturnaround.jrebel.mybatis;
/*     */ 
/*     */ import java.io.FileNotFoundException;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.ibatis.builder.xml.XMLMapperBuilder;
/*     */ import org.apache.ibatis.executor.ErrorContext;
/*     */ import org.zeroturnaround.javarebel.ConfigurationFactory;
/*     */ import org.zeroturnaround.javarebel.Logger;
/*     */ import org.zeroturnaround.javarebel.LoggerFactory;
/*     */ import org.zeroturnaround.javarebel.integration.monitor.MonitoredResource;
/*     */ import org.zeroturnaround.javarebel.integration.util.MonitorUtil;
/*     */ import org.zeroturnaround.javarebel.integration.util.ResourceUtil;
/*     */ 
/*     */ public class SqlMapReloader
/*     */ {
/*  19 */   private static final Logger log = LoggerFactory.getLogger("MyBatis");
/*  20 */   private static final String MONITOR_KEY = String.valueOf(System.identityHashCode(SqlMapReloader.class));
/*  21 */   private static final int CHECK_INTERVAL = ConfigurationFactory.getInstance().getCheckInterval();
/*     */ 
/*  23 */   private Map<URL, MonitoredResource> monitoredFiles = Collections.synchronizedMap(new LinkedHashMap());
/*  24 */   private List<ResourceDesc> additionalMappings = Collections.synchronizedList(new ArrayList(1));
/*  25 */   private static final ThreadLocal<Set<String>> reloadedResources = new ThreadLocal();
/*     */   private JrConfiguration conf;
/*     */   private JrXMLConfigBuilder confBuilder;
/*     */   private volatile long lastCheck;
/*     */ 
/*     */   public SqlMapReloader(JrConfiguration conf)
/*     */   {
/*  33 */     this.conf = conf;
/*  34 */     this.lastCheck = System.currentTimeMillis();
/*     */   }
/*     */ 
/*     */   public void setConfigBuilder(JrXMLConfigBuilder confBuilder) {
/*  38 */     this.confBuilder = confBuilder;
/*     */   }
/*     */ 
/*     */   public void reload() {
/*  42 */     synchronized (this) {
/*  43 */       if (this.lastCheck + CHECK_INTERVAL < System.currentTimeMillis()) {
/*  44 */         if (hasChanged()) {
/*  45 */           reconfigure();
/*     */         }
/*  47 */         this.lastCheck = System.currentTimeMillis();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static boolean isReloading() {
/*  53 */     return MonitorUtil.isActive(MONITOR_KEY);
/*     */   }
/*     */ 
/*     */   public static boolean doReload(String s) {
/*  57 */     if (isReloading()) {
/*  58 */       Set set = (Set)reloadedResources.get();
/*  59 */       if ((set != null) && (!set.contains(s))) {
/*  60 */         set.add(s);
/*  61 */         return true;
/*     */       }
/*     */     }
/*  64 */     return false;
/*     */   }
/*     */ 
/*     */   private void reconfigure() {
/*  68 */     log.infoEcho("Reloading SQL maps");
/*     */ 
/*  70 */     this.conf.reinit();
/*     */ 
/*  72 */     reloadedResources.set(Collections.synchronizedSet(new HashSet()));
/*  73 */     MonitorUtil.enter(MONITOR_KEY);
/*     */     try {
/*  75 */       if (this.confBuilder != null)
/*  76 */         this.confBuilder.reinit();
/*  77 */       reconfigureAdditionalMappings();
/*     */ 
/*  80 */       MonitorUtil.exit(MONITOR_KEY);
/*  81 */       reloadedResources.remove();
/*     */     }
/*     */     finally
/*     */     {
/*  80 */       MonitorUtil.exit(MONITOR_KEY);
/*  81 */       reloadedResources.remove();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void reconfigureAdditionalMappings() {
/*  86 */     for (ResourceDesc rd : (ResourceDesc[])this.additionalMappings.toArray(new ResourceDesc[0]))
/*  87 */       reconfigureMapping(rd);
/*     */   }
/*     */ 
/*     */   private void reconfigureMapping(ResourceDesc rd)
/*     */   {
/*  92 */     org.apache.ibatis.session.Configuration c = (org.apache.ibatis.session.Configuration)this.conf;
/*     */     try {
/*  94 */       XMLMapperBuilder xmlMapperBuilder = new XMLMapperBuilder(ResourceUtil.asInputStream(rd.url), c, rd.path, c.getSqlFragments());
/*     */ 
/*  96 */       xmlMapperBuilder.parse();
/*     */     }
/*     */     catch (Exception e) {
/*  99 */       if ((e.getCause() instanceof FileNotFoundException)) removeMappingForDeletedResource(rd); else
/* 100 */         throw new RuntimeException("Failed to parse mapping resource: '" + rd.url + "'", e);
/*     */     }
/*     */     finally {
/* 103 */       ErrorContext.instance().reset();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void removeMappingForDeletedResource(ResourceDesc rd) {
/* 108 */     log.info("Stopped monitoring resource " + rd.url);
/* 109 */     this.monitoredFiles.remove(rd.url);
/* 110 */     this.additionalMappings.remove(rd);
/*     */   }
/*     */ 
/*     */   private boolean hasChanged() {
/* 114 */     boolean hasChanged = false;
/* 115 */     Collection files = Arrays.asList(this.monitoredFiles.values().toArray(new MonitoredResource[0]));
/*     */ 
/* 117 */     for (MonitoredResource file : files) {
/* 118 */       hasChanged |= file.modified();
/*     */     }
/*     */ 
/* 121 */     return hasChanged;
/*     */   }
/*     */ 
/*     */   public void enterConf()
/*     */   {
/* 128 */     ResourceContext.enter();
/*     */   }
/*     */ 
/*     */   public void exitConf()
/*     */   {
/* 135 */     Collection resources = ResourceContext.exit();
/* 136 */     for (URL url : resources)
/* 137 */       if (!this.monitoredFiles.containsKey(url)) {
/* 138 */         log.info("Monitoring resource " + url);
/*     */ 
/* 140 */         MonitoredResource file = new MonitoredResource(ResourceUtil.asResource(url));
/* 141 */         this.monitoredFiles.put(url, file);
/*     */       }
/*     */   }
/*     */ 
/*     */   public void addMapping(URL url, String path)
/*     */   {
/* 147 */     if (this.monitoredFiles.containsKey(url)) {
/* 148 */       return;
/*     */     }
/* 150 */     MonitoredResource file = new MonitoredResource(ResourceUtil.asResource(url));
/* 151 */     log.info("Monitoring resource '" + url + "' from '" + path + "'");
/* 152 */     this.monitoredFiles.put(url, file);
/* 153 */     this.additionalMappings.add(new ResourceDesc(url, path));
/*     */   }
/*     */ 
/*     */   public boolean mappingsLoadedFromSameLocation() {
/* 157 */     if (this.additionalMappings.isEmpty()) return false;
/*     */ 
/* 159 */     boolean result = true;
/* 160 */     String firstMappingBaseUrl = ((ResourceDesc)this.additionalMappings.get(0)).getBaseUrl();
/* 161 */     for (ResourceDesc rd : this.additionalMappings) {
/* 162 */       result &= rd.getBaseUrl().equalsIgnoreCase(firstMappingBaseUrl);
/*     */     }
/*     */ 
/* 165 */     return result;
/*     */   }
/*     */ 
/*     */   public String buildUrlBasedOnFirstMapping(Class<?> type) {
/* 169 */     if (this.additionalMappings.isEmpty()) return "";
/*     */ 
/* 172 */     return ((ResourceDesc)this.additionalMappings.get(0)).getBaseUrl() + type
/* 172 */       .getSimpleName() + ".xml";
/*     */   }
/*     */ 
/*     */   public String buildPathBasedOnFirstMapping(Class<?> type) {
/* 176 */     if (this.additionalMappings.isEmpty()) return "";
/*     */ 
/* 178 */     String firstMappingPath = ((ResourceDesc)this.additionalMappings.get(0)).path;
/* 179 */     int extensionIndex = firstMappingPath.lastIndexOf(".xml");
/*     */ 
/* 182 */     return ((ResourceDesc)this.additionalMappings.get(0)).getBasePath() + type
/* 182 */       .getSimpleName() + firstMappingPath.substring(extensionIndex);
/*     */   }
/*     */   private static class ResourceDesc {
/*     */     final URL url;
/*     */     final String path;
/*     */ 
/* 190 */     ResourceDesc(URL url, String path) { this.url = url;
/* 191 */       this.path = path; }
/*     */ 
/*     */     String getBaseUrl()
/*     */     {
/* 195 */       String url = this.url.toString();
/* 196 */       int lastSeparatorIndex = url.lastIndexOf('/');
/* 197 */       return url.substring(0, lastSeparatorIndex) + "/";
/*     */     }
/*     */ 
/*     */     String getBasePath() {
/* 201 */       String separator = "/";
/* 202 */       int lastSeparatorIndex = this.path.lastIndexOf(separator);
/*     */ 
/* 204 */       if (lastSeparatorIndex < 0) {
/* 205 */         separator = "\\";
/* 206 */         lastSeparatorIndex = this.path.lastIndexOf(separator);
/*     */       }
/*     */ 
/* 209 */       return this.path.substring(0, lastSeparatorIndex) + separator;
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\eclipse-jee-juno-SR2-win32\plugins\org.zeroturnaround.eclipse.embedder_5.3.1.RELEASE-201307081557\jrebel\mybatis-jr-plugin-5.6.3a.jar
 * Qualified Name:     org.zeroturnaround.jrebel.mybatis.SqlMapReloader
 * JD-Core Version:    0.6.0
 */