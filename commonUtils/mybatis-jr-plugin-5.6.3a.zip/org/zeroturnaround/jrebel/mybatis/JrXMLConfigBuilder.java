package org.zeroturnaround.jrebel.mybatis;

public abstract interface JrXMLConfigBuilder
{
  public abstract void reinit();
}

/* Location:           F:\eclipse-jee-juno-SR2-win32\plugins\org.zeroturnaround.eclipse.embedder_5.3.1.RELEASE-201307081557\jrebel\mybatis-jr-plugin-5.6.3a.jar
 * Qualified Name:     org.zeroturnaround.jrebel.mybatis.JrXMLConfigBuilder
 * JD-Core Version:    0.6.0
 */